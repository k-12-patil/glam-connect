import React from "react";


export default function About() {

  const cards = [
    {
      img: "/-/media/project/loreal/brand-sites/mny/americas/us/about-us/maybelline-lp-about-606x911.jpg?rev=f34db76aace140298b6759a832b07b76",
      alt: "maybelline lp about 606x911",
      title: "Makeup for every look, style, skin tone",
    },
    {
      img: "/-/media/project/loreal/brand-sites/mny/master/dmi/about-us-2024/mny_aboutus_03b_we_believe_in.jpg?rev=-1",
      alt: "",
      title: "Trendsetting looks from NYC",
    },
    {
      img: "/-/media/project/loreal/brand-sites/mny/master/dmi/about-us-2024/mny_aboutus_03c_we_believe_in.jpg?rev=-1",
      alt: "",
      title: "Fast + easy on the go makeup",
    },
    {
      img: "/-/media/project/loreal/brand-sites/mny/master/dmi/about-us-2024/mny_aboutus_03d_we_believe_in.jpg?rev=-1",
      alt: "",
      title: "Makeup that stands up to the city",
    },
  ];
  return (
    <div className="about-page">
      {/* Hero Section */}
      <section className="about">
  <h1><b>About Us</b></h1>
  <p>
    Welcome to <strong>Glamora</strong> — where beauty meets elegance.
    We craft premium, cruelty-free makeup products that empower you to
    embrace your individuality. Every shade, texture, and product is
    designed with love, care, and a commitment to sustainability, so
    you can feel confident, radiant, and uniquely you every single day.
  </p>
</section>

     

      {/* Founder Section */}
  <section className="founder">
  <div className="founder-image">
    <img
      src="https://amoeboids.com/wp-content/uploads/2023/03/12-Inspiring-Product-Vision-Examples-banner1.webp"
      alt="Founder Vision"
      style={{ borderRadius: "12px", objectFit: "cover", width: "100%", maxWidth: "400px" }}
    />
  </div>
  <div className="founder-text">
    <h2>Our Founders’ Vision – Shaping a Future Where Beauty Empowers</h2>
    <p>
      At <strong>Glamora</strong>, our vision is driven by an unstoppable team:  
      <strong>Devyani Mahajan, Ashwini Patil, Paavani Chaudhari, Gauri Lone</strong>.  
      United by passion and purpose, we are revolutionizing beauty—crafting cruelty-free, sustainable products that empower you to shine with confidence and authenticity every day.
    </p>
  </div>
</section>

<br/><br/>

<section>
    <div
      data-qa="new-transporter-slider"
      role="group"
      aria-roledescription="carousel"
      className="new-transporter-slider disable-carousel scaled"
    >
      <div className="new-transporter-slider-carousel center-items" style={{ transform: "translateX(0px)" }}>
        {cards.map((card, index) => (
          <div
            key={index}
            data-qa="ntp-card"
            className={`new-transporter-card ${index === 0 ? "active" : ""}`}
          >
            <div className="new-transporter-card__wrapper no-outline">
              <picture data-qa="ntp-picture" className="new-transporter-card__image-wrapper">
                <source media="(min-width: 1280px)" srcSet={card.img} />
                <source media="(min-width: 768px)" srcSet={card.img} />
                <source srcSet={card.img} />
                <img
                  src={card.img}
                  data-lazy={card.img}
                  alt={card.alt}
                  className="new-transporter-card__image -loaded"
                />
              </picture>
              <div className="new-transporter-card__wrapper-content">
                <a
                  aria-label={card.title}
                  className="new-transporter-card__link-title without-transporter-url"
                >
                  <span className="new-transporter-card__main-title">{card.title}</span>
                </a>
              </div>
            </div>
            <p className="new-transporter-card__description"></p>
          </div>
        ))}
      </div>
    </div>
</section>


<br/><br/>





      {/* Mission Section */}
      <section className="mission">
  <div className="mission-text">
    <h2><b>Illuminating Your Beauty, Defining Timeless Elegance</b></h2>
    <p>
      At <strong>Glamora</strong>, we believe beauty should be as unique as you are. 
      Our handpicked collection blends luxury, sustainability, and ethical practices 
      to bring you products that enhance your natural charm while caring for the 
      planet. We don’t just create makeup — we create confidence, radiance, 
      and elegance that never fades.
    </p>
    <div className="mission-info">
      <img src="https://via.placeholder.com/50" alt="Mission Icon" />
      <span>Our Brand Values</span>
    </div>
  </div>
  <div className="mission-image">
    <img
      src="https://via.placeholder.com/400x300"
      alt="Product Showcase"
    />
  </div>
</section>


      {/* Team Section */}
      <section className="team">
  <h2><b>Meet the Visionaries Behind Glamora</b></h2>
  <p>
    At <strong>Glamora</strong>, our strength lies in the passion and creativity of our people. 
    From innovative designers to strategic thinkers, every member of our team shares one goal — 
    to craft beauty experiences that inspire, empower, and leave a lasting impression.
  </p>
  <div className="team-grid">
    <div className="team-member">
      <img src="https://via.placeholder.com/200" alt="Team Member" />
      <h3>Devyani Mahajan</h3>
      <p>Founder & CEO</p>
    </div>
    <div className="team-member">
      <img src="https://via.placeholder.com/200" alt="Team Member" />
      <h3>Ashwini Patil</h3>
      <p>Creative Director</p>
    </div>
    <div className="team-member">
      <img src="https://via.placeholder.com/200" alt="Team Member" />
      <h3>Paavani Chaudhari</h3>
      <p>Marketing Manager</p>
    </div>
    <div className="team-member">
      <img src="https://via.placeholder.com/200" alt="Team Member" />
      <h3>Gauri Lone</h3>
      <p>Product Manager</p>
    </div>
  </div>
</section>


      
     
    </div>
  );
}